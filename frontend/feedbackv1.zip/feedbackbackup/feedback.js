let selectedRetention = null;
let selectedRating = null;
let selectedTheme = 'nature';
let userData = {};

// Character counter for pledge
document.addEventListener('DOMContentLoaded', function() {
    const pledgeTextarea = document.getElementById('pledge-text');
    if (pledgeTextarea) {
        pledgeTextarea.addEventListener('input', function() {
            document.getElementById('char-count').textContent = this.value.length;
        });
    }
});

function showConsentPage() {
    document.getElementById('landing-page').style.display = 'none';
    document.getElementById('consent-page').style.display = 'flex';
}

function selectOption(option, element) {
    document.querySelectorAll('.retention-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    element.classList.add('selected');
    selectedRetention = option;
    document.getElementById('proceedBtn').disabled = false;
}

function showDetailsPage() {
    if (selectedRetention) {
        document.getElementById('consent-page').style.display = 'none';
        document.getElementById('details-page').style.display = 'flex';
    }
}

function submitDetails(event) {
    event.preventDefault();
    userData.name = document.getElementById('user-name').value;
    userData.email = document.getElementById('user-email').value;
    
    if (userData.name && userData.email) {
        document.getElementById('details-page').style.display = 'none';
        document.getElementById('feedback-page').style.display = 'flex';
    }
}

function selectRating(rating, element) {
    document.querySelectorAll('.rating-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    element.classList.add('selected');
    selectedRating = rating;
}

function submitFeedback(event) {
    event.preventDefault();
    
    if (!selectedRating) {
        alert('Please rate your experience before continuing.');
        return;
    }
    
    userData.q2 = document.getElementById('q2').value;
    userData.q3 = document.getElementById('q3').value;
    userData.rating = selectedRating;
    
    document.getElementById('feedback-page').style.display = 'none';
    document.getElementById('pledge-page').style.display = 'flex';
}

function submitPledge(event) {
    event.preventDefault();
    userData.pledge = document.getElementById('pledge-text').value;
    
    document.getElementById('pledge-page').style.display = 'none';
    document.getElementById('photo-page').style.display = 'flex';
}

function capturePhoto() {
    // Simulate photo capture
    setTimeout(() => {
        document.getElementById('photo-page').style.display = 'none';
        document.getElementById('style-page').style.display = 'flex';
    }, 500);
}

function selectTheme(theme, element) {
    document.querySelectorAll('.theme-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    element.classList.add('selected');
    selectedTheme = theme;
    
    const themeNames = {
        'energy': 'Energy Theme',
        'nature': 'Nature Theme',
        'ocean': 'Ocean Theme',
        'recycle': 'Recycle Theme',
        'tech': 'Tech Theme'
    };
    document.getElementById('selected-theme-name').textContent = themeNames[theme];
}

function confirmStyle() {
    document.getElementById('style-page').style.display = 'none';
    document.getElementById('confirmation-page').style.display = 'flex';
    
    // Populate confirmation details
    document.getElementById('confirm-name').textContent = userData.name;
    document.getElementById('confirm-email').textContent = userData.email;
    document.getElementById('confirm-rating').textContent = '⭐'.repeat(selectedRating) + ` (${selectedRating}/5)`;
    document.getElementById('confirm-theme').textContent = selectedTheme;
    document.getElementById('confirm-retention').textContent = selectedRetention === '7days' ? '7 Days' : 'Permanent storage';
    document.getElementById('confirm-pledge').textContent = userData.pledge;
}

function retakePhoto() {
    document.getElementById('style-page').style.display = 'none';
    document.getElementById('photo-page').style.display = 'flex';
}

function goBackToStyle() {
    document.getElementById('confirmation-page').style.display = 'none';
    document.getElementById('style-page').style.display = 'flex';
}

function finalSubmit() {
    document.getElementById('confirmation-page').style.display = 'none';
    document.getElementById('thankyou-page').style.display = 'flex';
}

function submitAnother() {
    // Reset all data
    selectedRetention = null;
    selectedRating = null;
    selectedTheme = 'nature';
    userData = {};
    
    // Reset forms
    document.querySelectorAll('form').forEach(form => form.reset());
    document.querySelectorAll('.selected').forEach(el => el.classList.remove('selected'));
    document.getElementById('proceedBtn').disabled = true;
    
    // Go back to landing page
    document.getElementById('thankyou-page').style.display = 'none';
    document.getElementById('landing-page').style.display = 'flex';
}